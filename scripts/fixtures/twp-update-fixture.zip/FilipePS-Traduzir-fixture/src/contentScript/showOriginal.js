// showOriginal.js fixture
