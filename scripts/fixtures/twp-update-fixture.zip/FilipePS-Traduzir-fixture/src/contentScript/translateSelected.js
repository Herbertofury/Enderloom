// translateSelected.js fixture
