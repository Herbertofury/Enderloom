// pageTranslator.js fixture
