// showTranslated.js fixture
