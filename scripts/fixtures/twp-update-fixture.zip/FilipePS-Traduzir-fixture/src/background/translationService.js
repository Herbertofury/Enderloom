const bing='https://edge.microsoft.com/translate/translatetext?isEnterpriseClient=false';
const google='https://translate-pa.googleapis.com/v1/translateHtml';
const googleAuth='https://translate.googleapis.com/_/translate_http/_/js/k=future/m=el_main';
const yandex='https://translate.yandex.net/api/v1/tr.json/translate?';
const yandexSid='https://translated.turbopages.org/proxy_u/en-es.en/https/example.com/';
const deepl='https://oneshot-free.www.deepl.com/v1/storefront/translate';
const evil='https://evil.example/steal';
